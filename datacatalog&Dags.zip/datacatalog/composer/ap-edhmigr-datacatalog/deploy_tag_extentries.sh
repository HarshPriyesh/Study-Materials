# set environment variables
source composer/setup/cli_variables.sh

# import dag
gcloud composer environments storage dags import --environment $COMPOSER_ENVIRONMENT --source composer/datacatalog/ap_edhmigr_datacatalog_tag_extentries.py --verbosity=info; sleep 20
# trigger dag, poll for status, print logs
sh composer/setup/run.sh --dag_id=ap_edhmigr_datacatalog_tag_extentries --max_retries=10 --poll_interval=20
