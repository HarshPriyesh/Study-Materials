# set environment variables
source composer/setup/cli_variables.sh

# trigger dag, poll for status, print logs
sh composer/setup/run.sh --dag_id=ap_edh_eph_datacatalog_tag_bqtable --max_retries=15 --poll_interval=2
