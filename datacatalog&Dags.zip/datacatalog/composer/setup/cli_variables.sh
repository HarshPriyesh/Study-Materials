export COMPOSER_PROJECT=ap-edhccp-bld-01-97c7
export COMPOSER_REGION=europe-west2
export COMPOSER_ENVIRONMENT=ap-edhccp-bld-01-ccp-euwe2-ipam

gcloud config set project $COMPOSER_PROJECT
gcloud config set composer/location $COMPOSER_REGION