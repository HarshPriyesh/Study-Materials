import os
import datetime
import pendulum

from airflow import models
from airflow.providers.google.cloud.operators import dataproc

PROJECT = models.Variable.get('dataproc_project', 'default')
REGION = models.Variable.get('region', 'default')
DATAPROC_CLUSTER = models.Variable.get('dataproc_cluster_core_05', 'default')
CODE_CONFIG_STAGING_BUCKET = models.Variable.get('config_staging_bucket', 'default')

dag_name = 'ap_edhmigr_batch3_hist_dataload'

shell_script = f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/scripts/trigger_file_movement.sh'
properties_files = [f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/scripts/gcs_local_gcs_unarch.sh',
                    f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/scripts/gcs_file_converter.sh',
                    f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/python/file_covert.py',
                    f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/python/hash_validation_checks.py',
                    f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/python/gcp_cnt_validation_checks.py',
                    f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/config/env_setup.sh',
                    f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/config/config_file_extractor_batch3.txt',
                    f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/historic_data_module/dependencies/spark-bigquery-latest_2.12.jar',
                    ]

shell_script_file_name = shell_script.rpartition("/")[-1]  # script.sh
# ['$PWD/one.properties', '$PWD/two.properties']
properties_files_pwd_uris = [os.path.join(
    "$PWD/", f.rpartition("/")[-1]) for f in properties_files]

PIG_JOB_SHELL_SCRIPT = {
    "reference": {"project_id": PROJECT},
    "placement": {"cluster_name": DATAPROC_CLUSTER},
    "pig_job": {
        "jar_file_uris": [shell_script] + properties_files,
        "query_list": {"queries": ["sh chmod 755 * ; sh bash " + shell_script_file_name + " " + DATAPROC_CLUSTER + " " + REGION + " config_file_extractor_batch3.txt"
                                   ]},
    },
    "labels": {
        "job_name": "ap_edhmigr_batch3_hist_dataload",
        "application": "history_data",
        "layer": "staging-historic-load",
    },
}

default_dag_args = {
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=5),
    'project_id': PROJECT,
    'location': REGION,
    'region': REGION,
}

with models.DAG(
    dag_name,
    start_date=pendulum.datetime(2022, 7, 10, tz="Europe/London"),
    #schedule_interval='0 */2 * * *',
    schedule_interval=None,
    default_args=default_dag_args,
    tags=['dataproc', 'history_data'],
) as dag:

    pig_task_shell_script = dataproc.DataprocSubmitJobOperator(
        task_id='pig_task_shell_script',
        job=PIG_JOB_SHELL_SCRIPT,
        asynchronous=False)
