#####################################################################################################
# Program Name : data_catalog_tag_ext_entries                                                    #
# Purpose      : The script reads a list of Bigquery tables, columns, Taxonomies and Policy Tag     #
#                and attaches the tags to the columns                                               #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Import required modules                                                                           #
#####################################################################################################

import json
import os
import sys
import data_catalog_operations as dco

#p_args = json.loads(sys.argv[1])

#gcp_project = p_args["project_id"]
#gcp_location = p_args["location"]
#param_file = p_args["param_file"]

gcp_project = sys.argv[1]
gcp_location = sys.argv[2]
#config_file = sys.argv[3]

#if len(config_file) != 0:
#    if dco.valid_config(config_file):
#        param_file = "data_catalog_" + config_file + "_config.txt"
#        paramfile = open(param_file, 'r')
#    else:
#        print("Param file name is invalid: %s" %(config_file))
#        sys.exit(1)
#else:
#    print("Param file value incorrect")
#    sys.exit(1)

paramfile = open("data_catalog_tag_external_entries_config.txt", 'r')

lines = paramfile.readlines()

for i in lines[1:]:
    params = i.split(',')
    entry_group_id = params[0].strip()
    entry_id = params[1].strip()
    column_id = params[2].strip()
    tag_template = params[3].strip()
    tag_template_field = params[4].strip()
    tag_name = "tag_" + entry_id.replace(".","_") + "_" + column_id
    args = '{"project_id": "%s", "location": "%s", "field": [{"%s":["%s"]}], "tag_template_id": "%s", "tag_name": "%s", "entry_group_id": "%s", "entry_id": "%s"}' %(gcp_project,gcp_location,tag_template_field,column_id,tag_template,tag_name,entry_group_id,entry_id)
    try:
        gcp_tag = dco.attach_tag(args)
        print("[INFO]:       Tag created %s" %(gcp_tag["name"]))
    except Exception as e:
        continue
