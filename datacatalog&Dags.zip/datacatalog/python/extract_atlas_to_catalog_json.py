#####################################################################################################
# Program Name : extract_atlas_to_catalog_json                                                      #
# Purpose      : The script reads a list of Bigquery tables, columns, Taxonomies and Policy Tag     #
#                and attaches the tags to the columns                                               #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Import required modules                                                                           #
#####################################################################################################

import json
import os
import sys
import data_catalog_operations as dco

#p_args = json.loads(sys.argv[1])

#p_args={"project_id":sys.argv[1], "location": sys.argv[2], "param_file": sys.argv[3]}

#config_file = sys.argv[3]
#
#if len(config_file) != 0:
#    if dco.valid_config(config_file):
#        param_file = "data_catalog_" + config_file + "_config.txt"
#        paramfile = open(param_file, 'r')
#    else:
#        print("Param file name is invalid: %s" %(config_file))
#        sys.exit(1)
#else:
#    print("Param file value incorrect")
#    sys.exit(1)

paramfile = open("data_catalog_create_schema_json_config.txt", 'r')

lines = paramfile.readlines()

for i in lines[1:]:
    atlas_extract = i.split(',')[0].strip()
    gcp_tgt = i.split(',')[1].strip()
    
    args = '{"atlas_json": "%s", "catalog_json": "%s"}' %(atlas_extract,gcp_tgt)
    dco.get_json_extract(args)
