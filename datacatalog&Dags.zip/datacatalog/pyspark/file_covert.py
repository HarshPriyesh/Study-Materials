#####################################################################################################
# Program Name : file_covert                                                                        #
# Purpose      : pyspark script to coonvert the file                                                #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Set program variables                                                                             #
#####################################################################################################

#use package org.apache.spark:spark-avro_2.12:2.4.1

import pyspark
from pyspark.sql import Row, SparkSession
from pyspark.context import SparkContext
from pyspark.sql.types import *
import os
import sys
import datetime
from google.cloud import storage
storage_client = storage.Client()

file_uri = sys.argv[1]
src_frmt = sys.argv[2]
tgt_frmt = sys.argv[3]
tgt_uri = sys.argv[4]
schema_file = sys.argv[5]
partition_ind = sys.argv[6]

print("[INFO]:    Parameters passed to the program are ....")

print("[INFO]:    file_uri = %s" %(file_uri))
print("[INFO]:    src_frmt = %s" %(src_frmt))
print("[INFO]:    tgt_frmt = %s" %(tgt_frmt))
print("[INFO]:    tgt_uri = %s" %(tgt_uri))
print("[INFO]:    schema_file = %s" %(schema_file))
print("[INFO]:    partition_ind = %s" %(partition_ind))

spark = SparkSession.builder\
        .master("yarn")\
        .enableHiveSupport()\
        .appName("file_co")\
        .getOrCreate()

sc = SparkContext.getOrCreate()

try:

    if src_frmt in ["csv", "text"]:
        bucket = schema_file.split("/")[2]
        file_name = "/".join(schema_file.split("/")[3:])
        bucket = storage_client.get_bucket(bucket)
        blob = bucket.blob(file_name)
        blob = blob.download_as_string()
        schema=StructType.fromJson(json.loads(blob))
        #input_df = spark.read.schema(schema).option("delimiter", delim_arg).csv(file_uri)
        input_df = spark.read.schema(schema).csv(file_uri)
    else:
        print("[INFO]:    Reading the source files to convert")
        input_df = spark.read.format(src_frmt).option("basePath", file_uri).load(file_uri)
        print("[INFO]:    Writing the target files")
        if partition_ind == '3':
            input_df.write.partitionBy("ingestion_year","ingestion_month","ingestion_day").format(tgt_frmt).mode("append").save(tgt_uri)
        elif partition_ind == '2':
            input_df.write.partitionBy("ingestion_year","ingestion_month").format(tgt_frmt).mode("append").save(tgt_uri)
        elif partition_ind == '1':
            input_df.write.partitionBy("ingestion_year").format(tgt_frmt).mode("append").save(tgt_uri)
        elif partition_ind == '0':
            input_df.write.format(tgt_frmt).mode("append").save(tgt_uri)
        else:
            raise Exception('Too many Partitions %s' %(partition_ind))
        

except Exception as e:
    print("[ERROR]:       File conversion failed %s" %(e))
    sys.exit(1)

finally:
    sc.stop()
    spark.stop()
