#####################################################################################################
# Program Name : gcp_cnt_validation_checks                                                          #
# Purpose      : pyspark script to Perform the file validations                                    #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Set program variables                                                                             #
#####################################################################################################

#use package org.apache.spark:spark-avro_2.12:2.4.1
#use jars gs://spark-lib/bigquery/spark-bigquery-latest.jar

import pyspark
from pyspark.sql import *
from pyspark.context import SparkContext
from pyspark.sql import HiveContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
import os
import sys
import datetime
from google.cloud import storage
storage_client = storage.Client()

# Set the parameters

hive_tbl = sys.argv[1]
src_cntrl_fl_uri = sys.argv[2]
gcp_data_fl_uri = sys.argv[3]
partition_ind = sys.argv[4]
gcp_bq_project = sys.argv[5]
gcp_bq_dataset = sys.argv[6]
gcp_bq_tbl = sys.argv[7]
src_frmt = sys.argv[8]
gcp_frmt = sys.argv[9]
temp_bucket = sys.argv[10]
part_col1 = sys.argv[11]
part_col2 = sys.argv[12]
part_col3 = sys.argv[13]

print("[INFO]:    The parameter information")
print("[INFO]:    parameter src_cntrl_fl_uri = %s" %(src_cntrl_fl_uri))

bq_tbl_nm = gcp_bq_project + ":" + gcp_bq_dataset + "." + gcp_bq_tbl

# Setting up the file schema
file_schema = StructType([StructField("base_path", StringType(), True),
                          StructField("ld_type", StringType(), True),
                          StructField("tbl_name", StringType(), True),
                          StructField("folder_sz", StringType(), True),
                          StructField("sz_unit", StringType(), True),
                          StructField("fl_cnt", StringType(), True),
                          StructField("row_cnt", StringType(), True),
                          StructField("f_path", StringType(), True),
                          StructField("layer", StringType(), True),
                          StructField("run_date", StringType(), True),
                          StructField("filter_expression", StringType(), True),
                          StructField("part_lvl", StringType(), True),
                          StructField("split_num", StringType(), True)])

# Setup the delimiter value

delimiter = ","

spark = SparkSession.builder\
        .master("yarn")\
        .enableHiveSupport()\
        .appName("cnt_val")\
        .getOrCreate()

sc = SparkContext.getOrCreate()
spark.conf.set('temporaryGcsBucket',temp_bucket)
sqlContext = HiveContext(sc)
sqlContext.setConf("spark.sql.hive.convertMetastoreOrc", "false")
spark.conf.set("spark.sql.caseSensitive", "true")

try:
    # Read the control file from the source

    print("[INFO]:    Reading the source control file %s" %(src_cntrl_fl_uri))

    #os_cmd = "gsutil cat %s" %(src_cntrl_fl_uri)
    #os_err = os.system(os_cmd)
    #print("command completed with cd %s" %(os_err))
    src = spark.read.schema(file_schema) \
               .format("csv") \
               .option("delimiter", delimiter) \
               .load(src_cntrl_fl_uri)
    
    print("[INFO]:    Show src file")
    src.show(10,False)

    src.createOrReplaceTempView("src")

    print("[INFO]:    Reading the GCP data file %s" %(gcp_data_fl_uri))
    gcp = spark.read.format(gcp_frmt) \
                    .option("basePath", gcp_data_fl_uri) \
                    .option("mergeSchema", "true") \
                    .load(gcp_data_fl_uri)
    
    #print("[INFO]:    Show gcp file")
    #gcp.show(10,False)

    if partition_ind == '3' :
        #gcp_cnt = gcp.withColumn("file_name", input_file_name()) \
        #             .withColumn("ingestion_day",split(element_at(split("file_name",'/'),-2),'=')[1]) \
        #             .withColumn("ingestion_month",split(element_at(split("file_name",'/'),-3),'=')[1]) \
        #             .withColumn("ingestion_year",split(element_at(split("file_name",'/'),-4),'=')[1]) \
        #             .groupBy("ingestion_year","ingestion_month","ingestion_day").count()
        
        gcp_cnt = gcp.groupBy("{}".format(part_col1), "{}".format(part_col2), "{}".format(part_col3)).count()

        src_cnt = spark.sql("""select *, 
                                      split(split(substring_index(f_path, '/', -2), '/')[0], '=')[1] as %s,
                                      split(split(substring_index(f_path, '/', -3), '/')[0], '=')[1] as %s,
                                      split(split(substring_index(f_path, '/', -4), '/')[0], '=')[1] as %s
                               from src""" %(part_col1,part_col2,part_col3))
    elif partition_ind == '2' :
        #gcp_cnt = gcp.withColumn("file_name", input_file_name()) \
        #             .withColumn("ingestion_month",split(element_at(split("file_name",'/'),-3),'=')[1]) \
        #             .withColumn("ingestion_year",split(element_at(split("file_name",'/'),-4),'=')[1]) \
        #             .groupBy("ingestion_year","ingestion_month").count().withColumn("ingestion_day", lit(0))
        
        gcp_cnt = gcp.groupBy("{}".format(part_col3), "{}".format(part_col2)).count().withColumn("ingestion_day", lit(0))
        
        src_cnt = spark.sql("""select *, 
                                      0 as ingestion_day,
                                      split(split(substring_index(f_path, '/', -2), '/')[0], '=')[1] as %s,
                                      split(split(substring_index(f_path, '/', -3), '/')[0], '=')[1] as %s
                               from src"""  %(part_col2,part_col3))
    elif partition_ind == '1' :
        #gcp_cnt = gcp.withColumn("file_name", input_file_name()) \
        #             .withColumn("ingestion_year",split(element_at(split("file_name",'/'),-4),'=')[1]) \
        #             .groupBy("ingestion_year").count().withColumn("ingestion_month", lit(0)).withColumn("ingestion_day", lit(0))
        
        gcp_cnt = gcp.groupBy("{}".format(part_col3)).count().withColumn("ingestion_month", lit(0)).withColumn("ingestion_day", lit(0))

        src_cnt = spark.sql("""select *, 
                                      0 as ingestion_day,
                                      0 as ingestion_month,
                                      split(split(substring_index(f_path, '/', -2), '/')[0], '=')[1] as %s
                               from src""" %(part_col3))
    elif partition_ind == '0' :
        gcp_cnt = gcp.withColumn("filename",regexp_replace(input_file_name(), gcp_data_fl_uri + "/", "")).groupBy("filename").count()
        src_cnt = src.withColumn("filename", element_at(split(col("f_path"),"/"), -1)).select("base_path", "ld_type", "tbl_name", "filename","row_cnt","split_num")
    else :
        raise Exception('Too Many partitions')

    #print("[INFO]:    Show src count file")
    #src_cnt.show(10,False)
    
    #print("[INFO]:    Show gcp count file")
    #gcp_cnt.show(10,False)

    gcp_cnt.createOrReplaceTempView("gcp_cnt")
    src_cnt.createOrReplaceTempView("src_cnt")

    print("[INFO]:    Create the BQ entry to compare the counts")

    if int(partition_ind) > 0 :
        bq_df = spark.sql(""" select '02' as rec_type,
                                     coalesce(a.tbl_name, 'NA') as tbl_nm,
                                     coalesce(unix_timestamp(current_timestamp()) * 1000000,100) as gcp_ld_ts,
                                     cast(a.%s as integer) as ingestion_year,
                                     cast(a.%s as integer) as ingestion_month,
                                     cast(a.%s as integer) as ingestion_day,
                                     cast(null as string) as file_nm,
                                     cast(a.row_cnt as integer) as cntrl_fl_cnt,
        							 cast(b.count as integer) as gcp_cnt,
                                     cast(null as string) as cntrl_fl_hash_key,
                                     cast(null as string) as gcp_hash_key,
                                     case when cast(a.row_cnt as integer) = cast(b.count as integer)
                                             then 'Y'
                                          when ld_type = 'RAW'
                                             then 'NA'
                                          else 'N'
                                     end as cnt_match_ind,
                                     cast(null as string) as hashkey_match_ind, 
                                     '%s' as src_frmt,
                                     '%s' as gcp_frmt,
                                     cast(b.count as integer) as gcp_rfrmt_cnt,
                                     case when cast(a.row_cnt as integer) = cast(b.count as integer)
                                             then 'Y'
                                          when ld_type = 'RAW'
                                             then 'NA'
                                          else 'N'
                                     end as rfrmt_cnt_match_ind
                              from src_cnt a
                              left outer join gcp_cnt b
                              on cast(a.%s as integer) = b.%s and
                                 cast(a.%s as integer) = b.%s and
                                 cast(a.%s as integer) = b.%s """ %(part_col3,part_col2,part_col1,src_frmt, gcp_frmt,part_col3,part_col3,part_col2,part_col2,part_col1,part_col1))
    else :
        bq_df = spark.sql(""" select '02' as rec_type,
                                     coalesce(tbl_nm, 'NA') as tbl_nm,
                                     coalesce(unix_timestamp(current_timestamp()) * 1000000,100) as gcp_ld_ts,
                                     0 as ingestion_year,
                                     0 as ingestion_month,
                                     0 as ingestion_day,
                                     cast(null as string) as file_nm,
                                     cast(cntrl_fl_cnt as integer) as cntrl_fl_cnt,
        							 cast(gcp_cnt as integer) as gcp_cnt,
                                     cast(null as string) as cntrl_fl_hash_key,
                                     cast(null as string) as gcp_hash_key,
                                     case when ld_type = 'TABLE' and cast(cntrl_fl_cnt as integer) = cast(gcp_cnt as integer)
                                             then 'Y'
                                          when ld_type = 'RAW'
                                             then 'NA'
                                          else 'N'
                                     end as cnt_match_ind,
                                     cast(null as string) as hashkey_match_ind,
                                     '%s' as src_frmt,
                                     '%s' as gcp_frmt,
                                     cast(gcp_cnt as integer) as gcp_rfrmt_cnt,
                                     case when ld_type = 'TABLE' and cast(cntrl_fl_cnt as integer) = cast(gcp_cnt as integer)
                                             then 'Y'
                                          when ld_type = 'RAW'
                                             then 'NA'
                                          else 'N'
                                     end as rfrmt_cnt_match_ind
                              from (select a.tbl_name as tbl_nm,
                                           sum(cast(b.count as integer)) as gcp_cnt,
                                           sum(cast(a.row_cnt as integer)) as cntrl_fl_cnt,
                                           a.ld_type
                                    from src_cnt a
                                    left outer join gcp_cnt b
                                    on a.filename = b.filename
                                    group by a.tbl_name,
                                             a.ld_type) tmp""" %(src_frmt, gcp_frmt))

    
    print("[INFO]:    Caching the results for frequent checks")
    bq_df.cache()
    
    print("[INFO]:    Check count of failed Validations")
    fail_cnt = bq_df.filter(col("cnt_match_ind") == 'N').count()

    #bq_df.printSchema()
    #print("[INFO]:    Show 10 records With failed Validation")
    #bq_df.filter(col("cnt_match_ind") == 'N').show(10, False)
    
    #print("[INFO]:    Show 10 records ")
    #bq_df.show(10, False)

    print("[INFO]:    Write the count validation results to BQ")
    #bq_df.write.format('bigquery') \
    #           .option('table', bq_tbl_nm) \
    #           .mode("Append") \
    #           .save()
    
    bq_df.write.format('bigquery') \
               .option('table', bq_tbl_nm) \
               .option("writeMethod", "direct") \
               .mode("Append") \
               .save()

    print("[INFO]:    Raise exception if the validation fails")
    if fail_cnt > 0 :
        raise Exception('Count Validation failed for %s files' %(fail_cnt))

except Exception as e:
    print("[ERROR]:       %s" %(e))
    sys.exit(1)

finally:
    sc.stop()
    spark.stop()
