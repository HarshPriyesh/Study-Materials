#!/bin/bash
ENV=$1
CONFIG_STAGING_BUCKET=$2

# Copy the jars and files to copy
echo "Copying scripts to gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/scripts/"
gsutil -m cp /app/scripts/*  gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/scripts/

echo "Copying pyspark scripts to gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/python/"
gsutil -m cp /app/pyspark/*  gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/python/

echo "Copying dependencies jars to gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/dependencies/"
gsutil -m cp /app/dependencies/*  gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/dependencies/


echo "Copying ${ENV} config to gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/config/"
gsutil -m cp -r /app/config/${ENV}/hdm/*  gs://${CONFIG_STAGING_BUCKET}/engine/historic_data_module/config/

