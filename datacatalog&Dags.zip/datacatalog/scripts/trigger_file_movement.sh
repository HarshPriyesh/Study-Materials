#####################################################################################################
# Program Name : trigger_file_movement                                                              #
# Purpose      : Script to move the datafiles the files                                             #
# Author       :                                                                                    #
#####################################################################################################

SCRIPT_NM=$(basename $0)
exec_time=$(date "+%Y%m%d%H%M%S")
if [[ ${4} == "" ]]
then 
    pid=$$
else
    pid=${4}
fi

#####################################################################################################
# Initialize Local variables                                                                        #
# The variables are set from a environment configuration file                                       #
# The parameters are not validated since the values will be passed to the script via a wrapper      #
#####################################################################################################

dataproc_cluster=${1}
cluster_region=${2}
hdm_config=${3}
# Cluster created with default FS as google storage, below snippet derives the storage location
cluster_gs_loc=$(gcloud dataproc clusters describe ${dataproc_cluster} --region ${cluster_region} | grep "core:fs.defaultFS:" | cut -d ":" -f 3,4 | tr -d ' ')
dataproc_gs_loc=${cluster_gs_loc%/}

echo "[INFO]:         Dataproc Cluster :  ${dataproc_cluster}"
echo "[INFO]:         Dataproc Cluster region : ${cluster_region}"

#####################################################################################################
# Initialize variables                                                                              #
# The variables are set from a environment configuration file                                       #
#####################################################################################################

# One time deletion of the BQ Table, will be commented for all runs
#bq query --use_legacy_sql=false "delete from \`ap-edhsta-bld-01-355b.ap_edhsta_bld_01_bqd_euwe2_recon.hist_data_recon\` where 1=1"

echo "[INFO]:         Initializing the global variables in the env_setup.sh"

. ${PWD}/env_setup.sh

#bash ${PWD}/generate_test_data.sh 

msg "Initializing the job variables in the ${hdm_config}"

awk 'NR>1' ${PWD}/${hdm_config} | while IFS=';' read -r f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13
do

    source_sys=$(echo ${f1}| tr -d '[:space:]')
    table_name=$(echo ${f2}| tr -d '[:space:]')
    landing_path=$(echo ${f3}| tr -d '[:space:]')
    input_format=$(echo ${f4}| tr -d '[:space:]')
    output_format=$(echo ${f5}| tr -d '[:space:]')
    destination_path=$(echo ${f6}| tr -d '[:space:]')
    mrg_ind=$(echo ${f7}| tr -d '[:space:]')
    block_sz=$(echo ${f8}| tr -d '[:space:]')
    partition_lvl=$(echo ${f9}| tr -d '[:space:]')
    tgt_layer=$(echo ${f10}| tr -d '[:space:]')
    split_num=$(echo ${f11}| tr -d '[:space:]')
    hive_db=$(echo ${f12}| tr -d '[:space:]')
    hive_tbl=$(echo ${f13}| tr -d '[:space:]')
    
    label_nm=${hive_db}_${hive_tbl}
	
    if [[ ${#label_nm} -gt 63 ]]
    then
        if [[ ${#hive_tbl} -gt 63 ]]
        then
            table_nm_lbl=${hive_tbl:0:63}
        else
            table_nm_lbl=${hive_tbl}
        fi
    else
        table_nm_lbl=${label_nm}
    fi

    #####################################################################################################
    # Variable checks                                                                                   #
    #####################################################################################################

    if [[ ${tgt_layer} == 'stg' ]]
    then 
        bq_project="${stg_gcp_project}"
        bq_dataset="${stg_bq_dataset}"
        bq_tbl="${stg_bq_tbl}"
    elif [[ ${tgt_layer} == 'con' ]]
    then 
        bq_project="${con_gcp_project}"
        bq_dataset="${con_bq_dataset}"
        bq_tbl="${con_bq_tbl}"
    fi
	
    #####################################################################################################
    # Un Archive the files to a staging location                                                        #
    #####################################################################################################

    msg "Unarchive the files for ${table_name} split ${split_num} to HDFS"

    # Changed to handle HAR folder #
    # HAR format is a folder and needs to be inside another folder to copy the HAR completely
    # file_uri="${input_path}/${file_name_prefix}.tar.${compression_type}"
    file_uri="${landing_path}"
    file_name_prefix="${source_sys}_${table_name}"

    bash gcs_local_gcs_unarch.sh "${file_uri}" "${file_name_prefix}" "${pid}" "${split_num}" "${input_format}" "${output_format}" "${partition_lvl}" "${block_sz}" "${dataproc_gs_loc}" "${dataproc_cluster}"

    if [[ $? -ne 0 ]]
    then
        err_msg "Failed to un archive the files for ${table_name} split ${split_num}" "${SCRIPT_NM}" "2"
        continue
    else
        if [[ ${block_sz} == "" ]]
        then 
            #src="/tmp/${pid}/unarch/${file_name_prefix}_${split_num}"
            src="hdfs://${dataproc_cluster}-m:8020/tmp/${pid}/unarch/${file_name_prefix}_${split_num}"
        else
            src="hdfs://${dataproc_cluster}-m:8020/tmp/${pid}/block_conv/${file_name_prefix}_${split_num}"
        fi
        #####################################################################################################
        # Validate the un archived files                                                                        #
        #####################################################################################################
        msg "Files un archived sucessfully to HDFS location ${src}"
        msg "Running validations on the un archived files ${src}"
        
        cntrl_fl_uri="${landing_path}/${prefix}${file_name_prefix}_${split_num}_recon_list.csv"
        gcp_cntrl_fl_uri="/tmp/${pid}/${file_name_prefix}_${split_num}_gcp_checksum.txt"
		#spark.jars.packages=org.apache.spark:spark-avro_2.12:2.4.1
        #--jars=gs://spark-lib/bigquery/spark-bigquery-latest.jar \
        #--properties="spark.dynamicAllocation.enabled=false,spark.shuffle.service.enabled=false,spark.executor.cores=5,spark.executor.memory=12000m,spark.executor.memoryOverhead=2048" \

        msg "executing -> ${PWD}/hash_validation_checks.py ${file_name_prefix} ${cntrl_fl_uri} ${gcp_cntrl_fl_uri} ${partition_lvl} ${bq_project} ${bq_dataset} ${bq_tbl} ${input_format} ${output_format} ${temp_bucket_pro}"

        if [[ ${output_format} == "" ]]
        then 
            gcp_format=${input_format}
        else 
            gcp_format=${output_format}
        fi
		
		
        gcloud dataproc jobs submit pyspark ${PWD}/hash_validation_checks.py \
        --labels="job_name=hash_validation_checks","application=history_data","layer=staging-historic-load","table_name=${table_nm_lbl}" \
        --cluster=${dataproc_cluster} \
        --region=${cluster_region} \
        --jars="${PWD}/spark-bigquery-latest_2.12.jar" \
        --properties="spark.dynamicAllocation.enabled=false,spark.shuffle.service.enabled=false" \
        -- ${table_name} ${cntrl_fl_uri} ${gcp_cntrl_fl_uri} ${partition_lvl} ${bq_project} ${bq_dataset} ${bq_tbl} ${input_format} ${gcp_format} ${temp_bucket_pro}

        py_err=$?

        if [[ ${py_err} -ne 0 ]]
        then
            err_msg "Pyspark Job exited with error ${py_err}" "${script_name}" "${py_err}"
            continue
        else
            #####################################################################################################
            # Convert and move the extracted files                                                              #
            #####################################################################################################
            msg "File validated successfully ${src}"
            msg "Converting and moving the files into the Target"
            
            #Destination URI chnaged to accept fullt qualified path form the param file.
            #destination_uri="${destination_path}/${table_name}"
            destination_uri="${destination_path}"
            #msg "Cleanup the destination URI"
            #gsutil -m rm -r ${destination_uri}
            
            if [[ ${output_format} == "" ]]
            then
                msg "File conversion not applicable"
                msg "Moving the files to destination ${destination_uri}"
                #destination_uri="${destination_path}/${table_name}"
                #gsutil -m cp -r ${staging_uri} ${destination_uri}

                msg "Copy a 0 byte file too destination to create the folder if not exists"
                touch _SUCCESS
                gsutil cp _SUCCESS ${destination_uri}/
                
                #hadoop distcp -overwrite ${src}/* ${destination_uri}
                #hadoop distcp ${src}/* ${destination_uri}
                #gsutil -m cp -r ${dataproc_gs_loc}${src}/* ${destination_uri}
                extract_folder="/tmp/${pid}/tgt/${source_sys}_${table_name}_${split_num}"
                mkdir -p ${extract_folder}
				hdfs dfs -get ${src}/* ${extract_folder}
                gsutil -m cp -r ${extract_folder}/* ${destination_uri}
                
                if [[ $? -ne 0 ]]
                then
                    err_msg "Copying files to destination failed" "${SCRIPT_NM}" "4"
                    continue
                fi
                gsutil rm ${destination_uri}/_SUCCESS
            else
                msg "Converting the files from ${input_format} to ${output_format}"
                if [[ ${input_format} == "csv" ]] || [[ ${input_format} == "text" ]]
                then
                    schema_file="${schema_bucket}/${file_name_prefix}.txt"
                else
                    schema_file="NA"
                fi

                bash gcs_file_converter.sh "${src}" "${input_format}" "${output_format}" "${destination_uri}" "${dataproc_cluster}" "${cluster_region}" "${schema_file}" "${partition_lvl}"

                if [[ $? -ne 0 ]]
                then
                    err_msg "File conversion Failed" "${SCRIPT_NM}" "5"
                    continue
                fi
                #    gcloud dataproc jobs submit pyspark ${PWD}/gcp_cnt_validation_checks.py \
                #    --cluster ${dataproc_cluster} \
                #    --region ${cluster_region} \
                #    --properties spark.jar.packages='org.apache.spark:spark-avro_2.12:2.4.1' \
                #    --jars=gs://spark-lib/bigquery/spark-bigquery-latest.jar \
                #    -- ${file_name_prefix} ${cntrl_fl_uri} ${destination_uri} ${partition_ind} ${bq_project} ${bq_dataset} ${bq_tbl} ${input_format} ${output_format}
                #    
                #    py_err=$?
				        #
                #    if [[ ${py_err} -ne 0 ]]
                #    then
                #       err_msg "Pyspark Job exited with error ${py_err}" "${script_name}" "${py_err}"
                #       continue
                #    fi
            fi
            msg "Copied the historical files for ${table_name} split ${split_num}"
            msg "Running validations on the historical files ${src}"

            cnt_cntrl_fl_uri="${landing_path}/${prefix}${file_name_prefix}_${split_num}.ctl.csv"
            #cnt_cntrl_fl_uri="${landing_path}/${prefix}${file_name_prefix}_${split_num}.stats.csv"
            
            #abs_path=$(gsutil ls -r ${destination_uri}/** | grep "part-" | head -1)
			if [[ ${partition_lvl} -eq 0 ]]
            then
                part_col1="ingestion_day"
                part_col2="ingestion_month"
                part_col3="ingestion_year"
            elif [[ ${partition_lvl} -eq 1 ]]
            then
                abs_path=$(gsutil ls -r ${destination_uri}/*/* | tail -1)
                msg "abs_path : ${abs_path}"
                part_col3=$(echo ${abs_path} | awk -F "[/=]" '{print $(NF-2)}')
                part_col2="ingestion_month"
                part_col1="ingestion_day"
            elif [[ ${partition_lvl} -eq 2 ]] 
            then
                abs_path=$(gsutil ls -r ${destination_uri}/*/*/* | tail -1)
                msg "abs_path : ${abs_path}"
                part_col2=$(echo ${abs_path} | awk -F "[/=]" '{print $(NF-2)}')
                part_col3=$(echo ${abs_path} | awk -F "[/=]" '{print $(NF-4)}')
                part_col1="ingestion_day"
            elif [[ ${partition_lvl} -eq 3 ]]
            then
                abs_path=$(gsutil ls -r ${destination_uri}/*/*/*/* | tail -1)
                msg "abs_path : ${abs_path}"
                part_col1=$(echo ${abs_path} | awk -F "[/=]" '{print $(NF-2)}')
                part_col2=$(echo ${abs_path} | awk -F "[/=]" '{print $(NF-4)}')
                part_col3=$(echo ${abs_path} | awk -F "[/=]" '{print $(NF-6)}')
            fi
            

            gcloud dataproc jobs submit pyspark ${PWD}/gcp_cnt_validation_checks.py \
            --labels="job_name=gcp_cnt_validation_checks","application=history_data","layer=staging-historic-load","table_name=${table_nm_lbl}" \
            --cluster ${dataproc_cluster} \
            --region ${cluster_region} \
            --properties spark.jar.packages='org.apache.spark:spark-avro_2.12:2.4.1' \
            --jars="${PWD}/spark-bigquery-latest_2.12.jar" \
            --properties="spark.dynamicAllocation.enabled=false,spark.shuffle.service.enabled=false" \
            -- ${table_name} ${cnt_cntrl_fl_uri} ${destination_uri} ${partition_lvl} ${bq_project} ${bq_dataset} ${bq_tbl} ${input_format} ${gcp_format} ${temp_bucket_pro} ${part_col1} ${part_col2} ${part_col3}

            py_err=$?

            if [[ ${py_err} -ne 0 ]]
            then
                err_msg "Pyspark Job exited with error ${py_err}" "${script_name}" "${py_err}"
                continue
            else 
                #####################################################################################################
                # Refresh hive table                                                                                #
                #####################################################################################################
                msg "Refresh the table partitions"
                msck_repair="MSCK REPAIR TABLE ${hive_db}.${hive_tbl};"
                gcloud dataproc jobs submit hive \
                --labels="job_name=msck_repair","application=history_data","layer=staging-historic-load","table_name=${table_nm_lbl}" \
                --cluster=${dataproc_cluster} \
                --region=${cluster_region} \
                --execute="${msck_repair}"
                
                hive_err=$?
                
                if [[ ${hive_err} -ne 0 ]]
                then
                    err_msg "Msck_repair job failed with error ${hive_err}" "${script_name}" "${hive_err}"
                    continue
                fi
            fi
        fi
    fi
done

#bq query --use_legacy_sql=false "select * from \`ap-edhsta-bld-01-355b.ap_edhsta_bld_01_bqd_euwe2_recon.hist_data_recon\`"

msg "Clean up the HDFS data"
hadoop fs -rm -r /tmp/${pid}

msg "Cleanup cluster HDFS"
hadoop fs -rm -r hdfs://${dataproc_cluster}-m:8020/tmp/${pid}

msg "Clean Local data"
rm -r /tmp/${pid}
#rm ${file_name_prefix}_${split_num}_gcp_checksum.txt


