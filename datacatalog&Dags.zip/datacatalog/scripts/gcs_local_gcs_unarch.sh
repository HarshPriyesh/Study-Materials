#####################################################################################################
# Program Name : gcs_local_gcs_untar                                                                #
# Purpose      : Script to untar the files                                                          #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Set program variables                                                                             #
#####################################################################################################

SCRIPT_NM=$(basename $0)
file_uri=${1}
file_name=${2}
folder=${3}
split_num=${4}
inp_frmt=${5}
op_frmt=${6}
partition_lvl=${7}
block_size=${8}
dataproc_gs_loc=${9}
dataproc_cluster=${10}

#file_name=$(echo ${file_uri} | awk -F "/" '{print $NF}')
#file_name_prefix=$(echo ${file_name} | awk -F "." '{print $1}')

msg "Processing the files for ${file_name} split ${split_num}"

checksum_file="${file_name}_${split_num}_gcp_checksum.txt"

msg "Creating a local folder to store temporary files"
local="/tmp/${folder}"
mkdir -p ${local}

#####################################################################################################
# Cleanup activities related to the script                                                          #
#####################################################################################################

msg "Removing stats file"
rm -f ${local}/${checksum_file}

#msg "Cleanup the staging location"
#gsutil -m rm -r ${target}
#gsutil rm ${staging_bucket}/${file_name}_checksum.txt


#####################################################################################################
# Copy the source file to Dataproc HDFS                                                             #
#####################################################################################################

msg "Copying ${file_uri} to HDFS"
#gsutil cp ${file_uri}* ${PWD}/${folder}
#dataproc_gs_loc=$(gcloud dataproc clusters describe ${dataproc_cluster} --region ${dataproc_region} | grep "core:fs.defaultFS:" | cut -d ":" -f 3,4 | tr -d ' ')
raw="/tmp/${folder}/raw/${file_name}_${split_num}"
#hadoop distcp ${file_uri}/*${file_name}_${split_num}* ${raw}
gsutil -m cp ${file_uri}/*${file_name}_${split_num}* ${dataproc_gs_loc}${raw}

if [[ $? -ne 0 ]]
then
    err_msg "${file_name} not found in the source uri" "${script_name}" "1"
    exit 1
else
    #####################################################################################################
    # Copy the har files folders                                                                        #
    #####################################################################################################
    hdfs dfs -ls ${raw}
    msg "Copy the hadoop archives to a local folder"
    tgt="/tmp/${folder}/archive/${prefix}${file_name}_${split_num}.har"
    echo "hdfs dfs -mkdir -p ${tgt}"
    hdfs dfs -mkdir -p ${tgt}
    
    for file in $(hdfs dfs -ls -C ${raw}/* | grep -v ".ctl.csv\|recon_list.csv")
    do 
        r_file=$(echo ${file/${prefix}${file_name}_${split_num}_/""} | awk -F "/" '{print $NF}')
        echo "hdfs dfs -cp ${file} ${tgt}/${r_file}"
        #hdfs dfs -cp ${file} ${tgt}/${r_file}
        gsutil cp ${dataproc_gs_loc}${file} ${dataproc_gs_loc}${tgt}/${r_file}
        err_cd=$?
        if [[ ${err_cd} -ne 0 ]]
        then
            err_msg "Failed to rename the file to remove ${prefix} for ${file} with err_cd ${err_cd}" "${script_name}" "2"
            exit 2
        fi
    done
    
	hdfs dfs -ls har://${tgt}
    har_hdfs_tgt="hdfs://${dataproc_cluster}-m:8020/tmp/${folder}/unarch/${file_name}_${split_num}"
	blk_cnv_hdfs_tgt="hdfs://${dataproc_cluster}-m:8020/tmp/${folder}/block_conv/${file_name}_${split_num}"
	#folder_nm=$(hdfs dfs -ls har://${tgt} | tail -1 | awk -F "/" '{print $NF}')
    #folder_nm=$(hdfs dfs -cat ${raw}/*.ctl.csv | head -2 | tail -1 | awk -F "," '{print $1}' | awk -F "/" '{print $(NF-1)}')
    #hdfs dfs -ls ${tgt}/${folder_nm}
    hdfs dfs -mkdir -p ${har_hdfs_tgt}
    #hdfs dfs -rm -r /tmp/${folder}/unarch/${file_name}_${split_num}/
    #echo "hadoop distcp har://${tgt}/ /tmp/${folder}/unarch/${file_name}_${split_num}/"
    #hadoop distcp har://${tgt}/${folder_nm} /tmp/${folder}/unarch/${file_name}/
    #hadoop distcp har://${tgt}/ /tmp/${folder}/unarch/${file_name}_${split_num}/
	echo "hdfs dfs -cp har://${tgt}/* ${har_hdfs_tgt}"
    hdfs dfs -cp har://${tgt}/* ${har_hdfs_tgt}
	err_cd=$?
	
	now=$(date '+%Y-%m-%d %H:%M:%S')

    if [[ ${err_cd} -ne 0 ]]
    then
        err_msg "Failed to extract the archive for ${file_name} with err_cd ${err_cd}" "${script_name}" "2"
        exit 2
    else
        if [[ ${block_size} == "" ]]
		then
		    msg "No Block conversion required"
		    #msg "Move the data to GCP"
		    #hadoop distcp /tmp/${folder}/unarch/${file_name} ${target}
            dataproc_hdfs_tgt=${har_hdfs_tgt}
        else
            msg "Converting the block size to ${block_size}"
            hdfs dfs -mkdir -p ${blk_cnv_hdfs_tgt}
            err_cd=$?
            if [[ ${err_cd} -ne 0 ]]
            then
                err_msg "Create HDFS directory failed with err_cd ${err_cd}" "${script_name}" "2"
                exit 2
            fi
        
		    hdfs dfs -D dfs.block.size=${block_size} -cp ${har_hdfs_tgt}/* ${blk_cnv_hdfs_tgt}
            err_cd=$?
            if [[ ${err_cd} -ne 0 ]]
            then
                err_msg "Failed to convert block size for ${file_name} with err_cd ${err_cd}" "${script_name}" "2"
                exit 2
            fi
		    msg "Move the data to GCP"
		    #hadoop distcp /tmp/${folder}/block_conv/${file_name} ${target}
            dataproc_hdfs_tgt=${blk_cnv_hdfs_tgt}
        fi
		
        msg "Calculate the Checksum of the extracted files"

		#touch ${file_name}_checksum.txt
		#cat /dev/null > ${file_name}_checksum.txt
		
		hdfs dfs -ls -R ${dataproc_hdfs_tgt} | head
        #hdfs dfs -cat /tmp/${folder}/unarch/${file_name}_${split_num}/*
        #export HADOOP_ROOT_LOGGER=DEBUG,console
        if [[ ${partition_lvl} == 0 ]]
        then
            msg "Processing Raw or unpartitioned table"
            #hadoop fs -Dfs.gs.checksum.type=MD5 -checksum /tmp/${folder}/unarch/${file_name}_${split_num}/*
            #msg "block size"
			#hdfs getconf -confkey dfs.blocksize
            #msg "Check checksum for one file"
            #hdfs dfs -cat /tmp/${folder}/unarch/${file_name}_${split_num}/Cap_balance.csv | md5sum
			#msg "Listed the file"
            #hdfs dfs -checksum /tmp/${folder}/unarch/${file_name}_${split_num}/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            hadoop fs -Dfs.gs.checksum.type=MD5 -checksum ${dataproc_hdfs_tgt}/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            err_cd=$?
        elif [[ ${partition_lvl} == 1 ]]
        then
            msg "Processing level 1 partition"
            #hdfs dfs -checksum /tmp/${folder}/unarch/${file_name}_${split_num}/*/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            hadoop fs -Dfs.gs.checksum.type=MD5 -checksum ${dataproc_hdfs_tgt}/*/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            err_cd=$?
        elif [[ ${partition_lvl} == 2 ]]
        then
            msg "Processing level 2 partition"
            #hdfs dfs -checksum /tmp/${folder}/unarch/${file_name}_${split_num}/*/*/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            hadoop fs -Dfs.gs.checksum.type=MD5 -checksum ${dataproc_hdfs_tgt}/*/*/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            err_cd=$?
        elif [[ ${partition_lvl} == 3 ]]
        then
            #msg "Get Block Size"
            #hdfs getconf -confkey dfs.blocksize
            #msg "Get file stats"
            #hdfs fsck ${dataproc_hdfs_tgt}/year=2021/month=6/day=3/part-00000-8b10c8be-4817-4e95-920a-2f890ee8873d.c000 -files -blocks
			#Present in Release Image 86
			msg "Processing level 3 partition"
            #hdfs dfs -checksum /tmp/${folder}/unarch/${file_name}_${split_num}/*/*/*/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            hadoop fs -Dfs.gs.checksum.type=MD5 -checksum ${dataproc_hdfs_tgt}/*/*/*/* | awk -v OFS="," '{print $1,$3}' >> ${local}/${checksum_file}
            err_cd=$?
        else
            msg "Too many partitions"
            err_cd=2
        fi
		
        if [[ ${err_cd} -ne 0 ]]
        then
            err_msg "Failed to calculate the checksum for ${file_name}" "${script_name}" "2"
            exit 2
        else
            ######################## Snippet to remove later ######################################
            #if [[ ${file_name} == "ACORN_raw" ]]
            #then
            #    echo -en "\n"
            #    msg "md5checksum Local"
            #    hdfs dfs -get /tmp/${folder}/unarch/${file_name}_${split_num}/acorn_2022-03-29T114507996Z.csv ${local}/
            #    hdfs dfs -cat /tmp/${folder}/unarch/${file_name}_${split_num}/acorn_2022-03-29T114507996Z.csv | md5sum 
            #    msg "md5checksum original"
            #    hdfs dfs -checksum /tmp/${folder}/unarch/${file_name}_${split_num}/acorn_2022-03-29T114507996Z.csv
            #    tr -d '\15\32' < ${local}/acorn_2022-03-29T114507996Z.csv > ${local}/acorn_converted_2022-03-29T114507996Z.csv
			#	 msg "md5checksum converted"
            #    hdfs dfs -put ${local}/acorn_converted_2022-03-29T114507996Z.csv /tmp/${folder}/
            #    hdfs dfs -checksum /tmp/${folder}/acorn_converted_2022-03-29T114507996Z.csv
            #    msg "Block size"
			#	 hdfs getconf -confkey dfs.blocksize
            #fi
			
            cat ${local}/${checksum_file} | head
            msg "Copying the checksum file to HDFS"
		    #hdfs dfs -put ${local}/${checksum_file} /tmp/${folder}/
            gsutil cp ${local}/${checksum_file} ${dataproc_gs_loc}/tmp/${folder}/
			err_cd=$?
            if [[ ${err_cd} -ne 0 ]]
            then 
                err_msg "Failed to move the checksum for ${file_name} to HDFS" "${script_name}" "2"
                exit 2
            fi
        fi
		
		#if [[ ${block_size} == "" ]]
		#then
		#    msg "No Block conversion required"
		#    #msg "Move the data to GCP"
		#    #hadoop distcp /tmp/${folder}/unarch/${file_name} ${target}
        #else
        #    msg "Converting the block size to ${block_size}"
        #    hdfs dfs -mkdir -p /tmp/${folder}/block_conv/${file_name}_${split_num}
        #    err_cd=$?
        #    if [[ ${err_cd} -ne 0 ]]
        #    then
        #        err_msg "Create HDFS directory failed with err_cd ${err_cd}" "${script_name}" "2"
        #        exit 2
        #    fi
        #
		#    hdfs dfs -D dfs.block.size=${block_size} -cp ${dataproc_hdfs_tgt} /tmp/${folder}/block_conv/${file_name}_${split_num}
        #    err_cd=$?
        #    if [[ ${err_cd} -ne 0 ]]
        #    then
        #        err_msg "Failed to convert block size for ${file_name} with err_cd ${err_cd}" "${script_name}" "2"
        #        exit 2
        #    fi
		#        msg "Move the data to GCP"
		#        #hadoop distcp /tmp/${folder}/block_conv/${file_name} ${target}
        #fi	

        #gsutil cp ${file_name}_checksum.txt ${staging_bucket}

        #echo "[INFO]:             Copy the Untar files to a intermediate GCS location"
        ##gsutil -m cp -r ${PWD}/${folder}/untar/* ${target}/
        #if [[ $? -ne 0 ]]
        #then
        #    echo "[ERROR]:            Failed to copy the ${file_name} tp GCS uri ${target}"
        #    echo "[INFO]:             script ${script_name} terminated"
        #    exit 3
        #else
        #    rm -r ${PWD}/${folder}
        #fi
    fi
fi

#hdfs dfs -ls /tmp/${folder}/unarch/${file_name}_${split_num}/*
#hdfs dfs -cat /tmp/${folder}/${checksum_file}
