#!/bin/bash
if [[ $JOB_NAME == "deploy_atlas_extract" ]]
  then
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_atlas_extract.sh
  elif [[ $JOB_NAME == "ap-edhmigr-datacatalog-copy-directory" ]]
  then
    echo "****************************** Copy Config and JSONs  ****************************"
    echo "gsutil -m cp config/bld-01/*  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/"
    gsutil cp config/bld-01/*.txt  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/
    echo "gsutil -m cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/"
    gsutil cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/
  elif [[ $JOB_NAME == "deploy_create_extentries" ]]
  then
    echo "gsutil -m cp config/bld-01/*  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/"
            gsutil cp config/bld-01/*.txt  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/
            echo "gsutil -m cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/"
            gsutil cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_create_extentries.sh
  elif [[ $JOB_NAME == "deploy_create_policytag" ]]
  then
    echo "gsutil -m cp config/bld-01/*  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/"
    gsutil cp config/bld-01/*.txt  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/
    echo "gsutil -m cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/"
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_create_policytag.sh
  elif [[ $JOB_NAME == "deploy_create_tags" ]]
  then
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_create_tags.sh
  elif [[ $JOB_NAME == "deploy_del_extentries" ]]
  then
      echo "gsutil -m cp config/bld-01/*  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/"
        gsutil cp config/bld-01/*.txt  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/
        echo "gsutil -m cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/"
        gsutil cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_del_extentries.sh
  elif [[ $JOB_NAME == "deploy_del_tagextentries" ]]
  then
    echo "gsutil -m cp config/bld-01/*  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/"
        gsutil cp config/bld-01/*.txt  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/
        echo "gsutil -m cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/"
        gsutil cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_del_tagextentries.sh
  elif [[ $JOB_NAME == "deploy_tag_bqtable" ]]
  then
    echo "gsutil -m cp config/bld-01/*  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/"
        gsutil cp config/bld-01/*.txt  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/
        echo "gsutil -m cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/"
        gsutil cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_tag_bqtable.sh
  elif [[ $JOB_NAME == "deploy_tag_extentries" ]]
  then
    echo "gsutil -m cp config/bld-01/*  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/"
        gsutil cp config/bld-01/*.txt  gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/config/
        echo "gsutil -m cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/"
        gsutil cp -r schema/* gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module/
      echo "****************************** Executing The Job ****************************"
      sh composer/ap-edhmigr-datacatalog/EPH_trigger/deploy_tag_extentries.sh
fi