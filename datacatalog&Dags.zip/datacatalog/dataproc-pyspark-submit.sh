#!/bin/bash

if [[ $JOB_NAME = "ap-edh-bdd-test-automation_cbs_mortgages" ]] #Jobname parameter mentioned in jenkins-parameters-file.yaml
then

    echo "****************************** Copying artifacts into Dataproc Staging bucket ******************************"
    gsutil cp -r bdd_test_automation gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/
	gsutil cp -r bdd_test_automation/pytest_main.py gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/pytest_main.py


    echo "****************************** Executing PySpark  Job  ****************************"

   gcloud dataproc jobs submit pyspark gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/pytest_main.py \
   --project=${PROJECT_ID} \
   --cluster=${DATAPROC_CLUSTER} \
   --bucket=${DATAPROC_STAGING_BUCKET} \
   --region=${REGION} \
   --py-files gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/common_test_cases_validators.zip,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/steps/datasource/cbs/delta/mortgages/test_cbs_delta_mortgages_raw.py,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/steps/datasource/cbs/delta/mortgages/test_cbs_delta_mortgages_staging.py,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/__init__.py,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/conftest.py,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/common_utils/test_common_utils.py,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/steps/datasource/cbs/delta/mortgages/test_cbs_delta_mortgages_landing.py\
   --files gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/features/datasource/cbs/delta/mortgages/cbs_delta_mortgages_raw.feature,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/features/datasource/cbs/delta/mortgages/cbs_delta_mortgages_staging.feature,gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/bdd_test_automation/features/datasource/cbs/delta/mortgages/cbs_delta_mortgages_landing.feature\
   -- --env=bld --test_file=test_cbs_delta_mortgages_staging.py --datasource_or_usecase=cbs --layer=staging
fi
