#1. Import python modules which are compatible with the Airflow version 2.2.3
import datetime
from tracemalloc import start
import pendulum
from airflow import models
from airflow.providers.google.cloud.operators import dataproc
from airflow.operators import bash_operator
#END 1. Import python modules which are compatible with the Airflow version 2.2.3

#2. Read Airflow variables
PROJECT_ID = models.Variable.get('dataproc_project', 'default')
REGION = models.Variable.get('region', 'default')
CLUSTER_NAME = models.Variable.get('cluster_name')
CODE_CONFIG_STAGING_BUCKET = models.Variable.get('config_staging_bucket', 'default')
CATALOG_PROJ = models.Variable.get('datacatalog_project', 'default')
CATALOG_LOC = models.Variable.get('region', 'default')
#END 2. Read Airflow variables

#3. Set job variables/parameters
JARS = [f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/data_catalog_module/python/data_catalog_bigquery_policy_tags.py',
        f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/data_catalog_module/python/data_catalog_operations.py',
        f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/data_catalog_module/config/data_catalog_tag_bigquery_col_config.txt']
QUERY = [f''' sh chmod 755 * ; sh python3 data_catalog_bigquery_policy_tags.py {CATALOG_PROJ} {CATALOG_LOC} ''']
#END 3. Set job variables/parameters
DATA_DOMAIN = 'eph_datacatelog'
JOB_NAME = 'ap_edh_eph_datacatelog_tag_bqtable'
TWS_JOB = 'na'
#4. Define tasks/jobs configuration
CREATE_DATAPROC_CLUSTER = 'True'
MASTER_MACHINE_TYPE = "n1-standard-8"
WORKER_MACHINE_TYPE = "n1-standard-8"
NUMBER_OF_DATAPROC_WORKERS = 2
WORKER_DISK_SIZE = 30

PIG_JOB_SCRIPT = {
    "reference": {"project_id": PROJECT_ID},
    "placement": {"cluster_name": CLUSTER_NAME},
    "pig_job": {
        "jar_file_uris": JARS,
        "query_list": {"queries": QUERY},
    },
    "labels": {
        "data_domain":"eph_datacatelog",
        "layer": "consumption",
        "job_type": "staging_bq",
        "job_name": "ap_edh_eph_datacatelog_tag_bqtable",
        "tws_job": "na",
    },
}
#END 4. Define tasks/jobs configuration

#5. Set default dag arguments
default_args  = {
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=5),
    'project_id': PROJECT_ID,
    'location': REGION,
    'region': REGION,
}
#END 5. Set default dag arguments
#6. Define dag
with models.DAG(
    dag_id='ap_edh_eph_datacatalog_tag_bqtable',
    start_date=pendulum.datetime(2022, 9, 19, tz="Europe/London"),
    schedule_interval=None,
    catchup=False,
    default_args=default_args ,
    tags=['data_domain:eph_datacatelog','layer:consumption','job_type:staging_bq','tws_job:na'],

) as dag:
#END 6. Define dag

    #7. Define tasks
    #User Tasks
    pig_job = dataproc.DataprocSubmitJobOperator(
        task_id="pig_job",
        job=PIG_JOB_SCRIPT,
        asynchronous=False,
        project_id=PROJECT_ID,
        region=REGION,
    )

    pig_ok = bash_operator.BashOperator(
        task_id='pig_ok',
        bash_command='echo Data Catalog Tag BQTable Job Successful')
    #END User Tasks
    #END 7. Define tasks

#8. Define dag dependencies
pig_job >> pig_ok
#END 8. Define dag dependencies