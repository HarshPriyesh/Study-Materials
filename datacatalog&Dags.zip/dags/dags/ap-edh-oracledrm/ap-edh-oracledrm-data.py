#1. Import python modules which are compatible with the Airflow version 2.2.3
import pendulum
from airflow import models
from airflow.utils.dates import days_ago
from airflow.providers.google.cloud.operators import dataproc
from airflow.operators import bash_operator
import time
import datetime
#END 1. Import python modules which are compatible with the Airflow version 2.2.3

#2. Read Airflow variables
PROJECT_ID = models.Variable.get('dataproc_project')
REGION = models.Variable.get('region')
CLUSTER_NAME = models.Variable.get('cluster_name')
CODE_CONFIG_STAGING_BUCKET = models.Variable.get('config_staging_bucket', 'default')
#END 2. Read Airflow variables

#3. Set job variables/parameters
shell_script_args = [
    '/tmp/ORACLE_DRM/cmp_oracledrm.properties',
     REGION,
     PROJECT_ID,
     CLUSTER_NAME,
     CODE_CONFIG_STAGING_BUCKET,
     models.Variable.get('landing_bucket', 'default'),
     models.Variable.get('oracledrm_raw_bucket', 'default'),
     models.Variable.get('oracledrm_staging_bucket', 'default'),
     models.Variable.get('oracledrm_archive_bucket', 'default'),
     models.Variable.get('bad_file_bucket', 'default')
      ]
#END 3. Set job variables/parameters

#4. Define tasks/jobs configuration
CREATE_DATAPROC_CLUSTER = 'True'
MASTER_MACHINE_TYPE = "n1-standard-8"
WORKER_MACHINE_TYPE = "n1-standard-8"
NUMBER_OF_DATAPROC_WORKERS = 5
WORKER_DISK_SIZE = 30

PIG_JOB = {
    "reference": {"project_id": PROJECT_ID},
    "placement": {"cluster_name": CLUSTER_NAME},
    "pig_job": {
        "query_list": {
            "queries": [
                'fs -rm -r -f file:///tmp/ORACLE_DRM/;',
                'fs -mkdir -p file:///tmp/ORACLE_DRM/;',
                f'fs -cp -f -p gs://{CODE_CONFIG_STAGING_BUCKET}/ORACLE_DRM_AL01767/engine/scripts/cmp_oracledrm/* file:///tmp/ORACLE_DRM/;',
                'sh chmod 750 /tmp/ORACLE_DRM/*.sh;',
                'sh /tmp/ORACLE_DRM/common-feed-loader.sh ' + (' ').join(shell_script_args) + " " + "{{dag_run.conf['schedule_date_time']}}"
                ]},
                },
                "labels": {
                    "data_domain": "oracle-drm",
                    "layer": "staging",
                    "job_type": "ingestion",
                    "job_name": "ap-edh-oracledrm-data",
                    "tws_job": "gcedh_dinodrmds_oracle_drm_al01767_ing",
                    },
}
#END 4. Define tasks/jobs configuration

#5. Set default dag arguments
default_args = {
    'retries': 0,
    'depends_on_past': False
}
#END 5. Set default dag arguments
#6. Define dag
with models.DAG(
    dag_id='ap-edh-oracledrm-data',
    description='oracledrm DAG to Create, Submit Pig Job and Delete a Ephemeral Dataproc Cluster',
    start_date=pendulum.datetime(2023, 1, 27, tz="Europe/London"),
    schedule_interval=None,
    catchup=False,
    #end_date = pendulum.datetime(2022, 9, 9, tz="Europe/London"),
    default_args=default_args,
    tags=['data_domain:oracle-drm','layer:staging','job_type:ingestion','tws_job:gcedh_dinodrmds_oracle_drm_al01767_ing'],
) as dag:
#END 6. Define dag

    #7. Define tasks
    #User Tasks
    pig_task = dataproc.DataprocSubmitJobOperator(
        task_id="pig_task",
        job=PIG_JOB,
        project_id=PROJECT_ID,
        region=REGION,
        asynchronous=False,
    )

    pig_ok = bash_operator.BashOperator(
        task_id='pig_ok',
        bash_command='echo ORACLE_DRM Data Pipeline Job Successful')
    #END User Tasks
    #END 7. Define tasks

#8. Define dag dependencies
pig_task >> pig_ok
#END 8. Define dag dependencies
