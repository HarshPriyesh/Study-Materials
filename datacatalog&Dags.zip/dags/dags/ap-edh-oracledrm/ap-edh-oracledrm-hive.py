#1. Import python modules which are compatible with the Airflow version 2.2.3
import pendulum
from airflow import models
from airflow.utils.dates import days_ago
from airflow.providers.google.cloud.operators import dataproc
from airflow.operators import bash_operator
import time
#END 1. Import python modules which are compatible with the Airflow version 2.2.3

#2. Read Airflow variables
PROJECT_ID = models.Variable.get('dataproc_project')
REGION = models.Variable.get('region')
CLUSTER_NAME = models.Variable.get('cluster_name')
CODE_CONFIG_STAGING_BUCKET = models.Variable.get('config_staging_bucket', 'default')
#END 2. Read Airflow variables

#3. Set job variables/parameters
STAGING_BUCKET = models.Variable.get('oracledrm_staging_bucket', 'default')
RAW_BUCKET = models.Variable.get('oracledrm_raw_bucket', 'default')
hivehqluri = "gs://{}/ORACLE_DRM_AL01767/hql/oracle_drm.hql".format(CODE_CONFIG_STAGING_BUCKET)
#END 3. Set job variables/parameters

#4. Define tasks/jobs configuration
CREATE_DATAPROC_CLUSTER = 'True'
MASTER_MACHINE_TYPE = "n1-standard-8"
WORKER_MACHINE_TYPE = "n1-standard-8"
NUMBER_OF_DATAPROC_WORKERS = 2
WORKER_DISK_SIZE = 30

HIVE_JOB = {
        "reference": {"project_id": PROJECT_ID},
        "placement": {"cluster_name": CLUSTER_NAME},
        "hive_job": { "query_file_uri":hivehqluri,
        "script_variables": {"stagingBucket": STAGING_BUCKET ,"rawBucket": RAW_BUCKET},},
        "labels": {
                        "data_domain": "oracle-drm",
                        "layer": "staging",
                        "job_type": "ingestion",
                        "job_name": "ap-edh-oracledrm-hive",
                        "tws_job": "na_adhoc",
                  },
    }
#END 4. Define tasks/jobs configuration

#5. Set default dag arguments
default_dag_args = {
        'retries': 0,
        'depends_on_past': False
}
#END 5. Set default dag arguments

#6. Define dag
with models.DAG(
        dag_id='ap-edh-oracledrm-hive',
        start_date=pendulum.datetime(2023, 1, 27, tz="Europe/London"),
        schedule_interval=None,
        catchup=False,
        default_args=default_dag_args) as dag:
#END 6. Define dag
    #7. Define tasks
    #User Tasks
    hive_job = dataproc.DataprocSubmitJobOperator(
            task_id='hive_job_creation',
            job=HIVE_JOB,
            region=REGION,
            project_id=PROJECT_ID,
            asynchronous=False,
            dag=dag)

    hive_ok = bash_operator.BashOperator(
            task_id='hive_ok',
            bash_command='echo Hive Job Successful')
    #END User Tasks
    #END 7. Define tasks
#8. Define dag dependencies
hive_job >> hive_ok
#END 8. Define dag dependencies